from decimal import Decimal, ROUND_HALF_UP

from django import template

register = template.Library()


@register.filter
def moneybr(value):
    try:
        amount = Decimal(value).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    except Exception:
        return "0,00"
    return f"{amount:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


@register.filter
def get_item(mapping, key):
    try:
        return mapping.get(key, {})
    except AttributeError:
        return {}


@register.filter
def get_amount(value):
    try:
        return value.get("amount", "")
    except AttributeError:
        return ""


@register.filter
def get_percentage(value):
    try:
        return value.get("percentage", "") or ""
    except AttributeError:
        return ""


@register.filter
def currency_symbol(code):
    return {"BRL": "R$", "USD": "US$", "EUR": "€"}.get(code, code or "")
