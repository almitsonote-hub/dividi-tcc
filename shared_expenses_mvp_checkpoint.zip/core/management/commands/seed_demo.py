from datetime import timedelta
from decimal import Decimal

from django.contrib.auth.models import User
from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from expenses.models import Category, Expense
from expenses.services import create_expense, money
from groups.models import ExpenseGroup, Membership
from settlements.services import create_settlement, current_liquidation, mark_paid


DEMO_PASSWORD = "Demo123!"
DEMO_USERS = [
    ("ana", "ana.demo@example.local"),
    ("bruno", "bruno.demo@example.local"),
    ("carla", "carla.demo@example.local"),
    ("diego", "diego.demo@example.local"),
    ("elisa", "elisa.demo@example.local"),
    ("felipe", "felipe.demo@example.local"),
    ("gabi", "gabi.demo@example.local"),
    ("henrique", "henrique.demo@example.local"),
]
CATEGORIES = [
    ("Alimentação", "alimentacao"),
    ("Transporte", "transporte"),
    ("Hospedagem", "hospedagem"),
    ("Compras", "compras"),
    ("Lazer", "lazer"),
    ("Contas", "contas"),
    ("Outros", "outros"),
]


class Command(BaseCommand):
    help = "Cria uma base fictícia coerente para demonstração do MVP."

    def add_arguments(self, parser):
        parser.add_argument("--reset", action="store_true", help="Remove e recria os dados da demonstração.")

    @transaction.atomic
    def handle(self, *args, **options):
        group_name = "Viagem para São Paulo"
        if options["reset"]:
            # Remover somente o grupo evita apagar contas demo que possam estar
            # sendo usadas em outros grupos locais.
            ExpenseGroup.objects.filter(name=group_name).delete()

        users = {}
        for username, email in DEMO_USERS:
            user, created = User.objects.get_or_create(username=username, defaults={"email": email})
            if created:
                user.set_password(DEMO_PASSWORD)
                user.save(update_fields=("password",))
            users[username] = user

        for name, slug in CATEGORIES:
            Category.objects.get_or_create(name=name, slug=slug, defaults={"active": True})

        group, group_created = ExpenseGroup.objects.get_or_create(
            name=group_name,
            defaults={
                "owner": users["ana"],
                "description": "Grupo fictício para demonstração do MVP do Dividi.",
                "currency": ExpenseGroup.Currency.BRL,
                "start_date": timezone.localdate() - timedelta(days=15),
            },
        )
        if not group_created:
            self.stdout.write(self.style.WARNING("Grupo de demonstração já existe. Use --reset para recriá-lo."))
            self._print_credentials()
            return

        memberships = {}
        for username, _ in DEMO_USERS:
            memberships[username] = Membership.objects.create(
                group=group,
                user=users[username],
                role=Membership.Role.OWNER if username == "ana" else Membership.Role.MEMBER,
            )
        members = list(memberships.values())
        categories = {c.slug: Category.objects.get(slug=c.slug) for c in Category.objects.all()}

        expense_specs = [
            ("Hotel", Decimal("960.00"), "hospedagem", "ana", ["ana", "bruno", "carla", "diego", "elisa", "felipe", "gabi", "henrique"], "equal"),
            ("Jantar 1", Decimal("240.00"), "alimentacao", "bruno", ["ana", "bruno", "carla", "diego"], "equal"),
            ("Jantar 2", Decimal("198.00"), "alimentacao", "carla", ["carla", "diego", "elisa", "felipe"], "equal"),
            ("Uber aeroporto", Decimal("84.50"), "transporte", "diego", ["ana", "bruno", "diego"], "custom"),
            ("Ingressos", Decimal("320.00"), "lazer", "elisa", ["ana", "carla", "elisa", "gabi"], "percentage"),
            ("Mercado", Decimal("176.40"), "compras", "felipe", ["bruno", "elisa", "felipe", "henrique"], "equal"),
            ("Almoço 1", Decimal("156.75"), "alimentacao", "gabi", ["ana", "gabi", "henrique"], "equal"),
            ("Almoço 2", Decimal("210.00"), "alimentacao", "henrique", ["ana", "bruno", "carla", "henrique"], "percentage"),
            ("Táxi", Decimal("72.00"), "transporte", "ana", ["ana", "bruno", "carla"], "equal"),
            ("Café", Decimal("48.30"), "alimentacao", "bruno", ["bruno", "diego", "felipe"], "equal"),
            ("Museu", Decimal("95.00"), "lazer", "carla", ["carla", "elisa", "gabi"], "equal"),
            ("Souvenirs", Decimal("120.00"), "compras", "diego", ["diego", "gabi", "henrique"], "percentage"),
            ("Jantar 3", Decimal("265.00"), "alimentacao", "elisa", ["ana", "elisa", "felipe", "gabi"], "equal"),
            ("Estacionamento", Decimal("60.00"), "transporte", "felipe", ["bruno", "felipe", "henrique"], "equal"),
            ("Padaria", Decimal("42.80"), "alimentacao", "gabi", ["ana", "bruno", "gabi"], "equal"),
            ("Conta extra", Decimal("132.00"), "contas", "henrique", ["carla", "diego", "elisa", "henrique"], "custom"),
            ("Almoço 3", Decimal("189.90"), "alimentacao", "bruno", ["ana", "bruno", "felipe", "henrique"], "equal"),
            ("Transporte local", Decimal("55.00"), "transporte", "carla", ["carla", "elisa", "gabi"], "equal"),
            ("Passeio", Decimal("225.00"), "lazer", "diego", ["ana", "diego", "felipe", "gabi"], "percentage"),
            ("Mercado 2", Decimal("115.55"), "compras", "ana", ["ana", "bruno", "carla", "diego"], "equal"),
            ("Jantar 4", Decimal("310.00"), "alimentacao", "felipe", ["elisa", "felipe", "gabi", "henrique"], "custom"),
            ("Café final", Decimal("36.00"), "alimentacao", "bruno", ["ana", "bruno", "carla"], "equal"),
            ("Hotel ajuste", Decimal("80.00"), "hospedagem", "ana", ["ana", "bruno", "carla", "diego", "elisa", "felipe", "gabi", "henrique"], "equal"),
            ("Compras finais", Decimal("90.00"), "compras", "carla", ["carla", "gabi", "henrique"], "equal"),
        ]

        today = timezone.localdate()
        for index, (description, amount, category, payer, participant_names, method) in enumerate(expense_specs):
            participant_memberships = [memberships[name] for name in participant_names]
            participant_ids = [m.id for m in participant_memberships]
            custom = None
            percentages = None
            if method == "custom":
                ratios = [Decimal("0.50"), Decimal("0.25"), Decimal("0.25")] if len(participant_ids) == 3 else [Decimal("0.35"), Decimal("0.25"), Decimal("0.20"), Decimal("0.20")]
                values = []
                remaining = money(amount)
                for ratio in ratios[:-1]:
                    value = money(amount * ratio)
                    values.append(value)
                    remaining = money(remaining - value)
                values.append(remaining)
                custom = dict(zip(participant_ids, values))
            elif method == "percentage":
                weights = [Decimal("25.00")] * len(participant_ids)
                weights[-1] += Decimal("100.00") - sum(weights)
                percentages = {pk: pct for pk, pct in zip(participant_ids, weights)}
            create_expense(
                group=group,
                user=users[payer],
                description=description,
                amount=amount,
                expense_date=today - timedelta(days=15 - min(index, 14)),
                category=categories[category],
                payer_id=memberships[payer].id,
                split_method=getattr(Expense.SplitMethod, method.upper()),
                participant_ids=participant_ids,
                custom_values=custom,
                percentages=percentages,
            )

        _, plan = current_liquidation(group)
        if plan:
            first = plan[0]
            settlement = create_settlement(group=group, user=users["ana"], payer_id=first["payer_id"], receiver_id=first["receiver_id"], amount=first["amount"])
            mark_paid(settlement=settlement, user=users["ana"])
        _, plan = current_liquidation(group)
        for item in plan[:2]:
            create_settlement(group=group, user=users["ana"], payer_id=item["payer_id"], receiver_id=item["receiver_id"], amount=item["amount"])
            _, plan = current_liquidation(group)
            if not plan:
                break

        self.stdout.write(self.style.SUCCESS("Base de demonstração criada."))
        self._print_credentials()

    def _print_credentials(self):
        self.stdout.write(f"Usuários: {', '.join(u[0] for u in DEMO_USERS)}")
        self.stdout.write(f"Senha de demonstração: {DEMO_PASSWORD}")
        self.stdout.write("Grupo: Viagem para São Paulo")
