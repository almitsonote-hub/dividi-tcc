from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Count
from django.shortcuts import render
from django.views import View

from groups.models import ExpenseGroup
from expenses.models import Expense
from settlements.models import Settlement


class HomeView(View):
    def get(self, request):
        if request.user.is_authenticated:
            return DashboardView.as_view()(request)
        return render(request, "core/home.html")


class DashboardView(LoginRequiredMixin, View):
    def get(self, request):
        groups = (
            ExpenseGroup.objects.filter(memberships__user=request.user)
            .annotate(expense_count=Count("expenses", distinct=True))
            .order_by("-created_at")
            .distinct()
        )
        context = {
            "groups": groups,
            "expense_count": Expense.objects.filter(group__memberships__user=request.user).count(),
            "pending_settlements": Settlement.objects.filter(
                group__memberships__user=request.user, status=Settlement.Status.PENDING
            ).count(),
        }
        return render(request, "core/dashboard.html", context)
