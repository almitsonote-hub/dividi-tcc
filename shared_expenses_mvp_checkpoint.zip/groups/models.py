from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone

from core.models import TimeStampedModel


class ExpenseGroup(TimeStampedModel):
    class Currency(models.TextChoices):
        BRL = "BRL", "Real brasileiro (R$)"
        USD = "USD", "Dólar americano (US$)"
        EUR = "EUR", "Euro (€)"

    owner = models.ForeignKey(User, on_delete=models.PROTECT, related_name="owned_expense_groups")
    name = models.CharField(max_length=120)
    description = models.TextField(blank=True)
    currency = models.CharField(max_length=3, choices=Currency.choices, default=Currency.BRL)
    start_date = models.DateField(default=timezone.localdate)
    end_date = models.DateField(blank=True, null=True)

    class Meta:
        ordering = ("-created_at",)

    def clean(self):
        if self.end_date and self.end_date < self.start_date:
            raise ValidationError({"end_date": "A data final não pode ser anterior à data inicial."})

    def __str__(self):
        return self.name


class Membership(TimeStampedModel):
    class Role(models.TextChoices):
        OWNER = "owner", "Responsável"
        MEMBER = "member", "Participante"

    group = models.ForeignKey(ExpenseGroup, on_delete=models.CASCADE, related_name="memberships")
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name="expense_memberships")
    role = models.CharField(max_length=10, choices=Role.choices, default=Role.MEMBER)
    joined_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=("group", "user"), name="unique_group_member")]
        ordering = ("user__username", "id")

    def __str__(self):
        return f"{self.user.get_username()} — {self.group.name}"
