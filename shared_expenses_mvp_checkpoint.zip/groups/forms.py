from django import forms
from django.contrib.auth.models import User

from .models import ExpenseGroup


class ExpenseGroupForm(forms.ModelForm):
    class Meta:
        model = ExpenseGroup
        fields = ("name", "description", "currency", "start_date", "end_date")
        widgets = {
            "start_date": forms.DateInput(attrs={"type": "date"}),
            "end_date": forms.DateInput(attrs={"type": "date"}),
        }


class ParticipantForm(forms.Form):
    username = forms.CharField(label="Usuário", max_length=150)

    def __init__(self, *args, **kwargs):
        self.group = kwargs.pop("group")
        super().__init__(*args, **kwargs)

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        try:
            user = User.objects.get(username__iexact=username)
        except User.DoesNotExist as exc:
            raise forms.ValidationError("Usuário não encontrado.") from exc
        if self.group.memberships.filter(user=user).exists():
            raise forms.ValidationError("Este usuário já participa do grupo.")
        return user
