from django.contrib import admin

from .models import ExpenseGroup, Membership


@admin.register(ExpenseGroup)
class ExpenseGroupAdmin(admin.ModelAdmin):
    list_display = ("name", "owner", "currency", "start_date", "end_date", "created_at")
    search_fields = ("name", "owner__username")


@admin.register(Membership)
class MembershipAdmin(admin.ModelAdmin):
    list_display = ("group", "user", "role", "joined_at")
    list_filter = ("role",)
    search_fields = ("group__name", "user__username")
