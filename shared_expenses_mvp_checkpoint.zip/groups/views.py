from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import transaction
from django.db.models import Count, Sum
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.views import View

from settlements.models import Settlement
from settlements.services import current_liquidation

from .forms import ExpenseGroupForm, ParticipantForm
from .models import ExpenseGroup, Membership


def get_member_group(request, pk):
    return get_object_or_404(ExpenseGroup, pk=pk, memberships__user=request.user)


def get_membership(request, group):
    return get_object_or_404(Membership, group=group, user=request.user)


class GroupDetailView(LoginRequiredMixin, View):
    def get(self, request, pk):
        group = get_member_group(request, pk)
        balances, liquidation = current_liquidation(group)
        pending = group.settlements.filter(status=Settlement.Status.PENDING).select_related("payer__user", "receiver__user")
        recent_expenses = group.expenses.select_related("payer__user", "category").prefetch_related("shares__participant__user")[:8]
        membership = get_membership(request, group)
        my_balance = balances["financial_balances"].get(membership.id, 0)
        context = {
            "group": group,
            "membership": membership,
            "my_balance": my_balance,
            "my_owes": abs(my_balance) if my_balance < 0 else 0,
            "my_receives": my_balance if my_balance > 0 else 0,
            "memberships": group.memberships.select_related("user"),
            "balances": balances,
            "liquidation": liquidation,
            "pending_settlements": pending,
            "recent_expenses": recent_expenses,
            "is_settled": not liquidation and not pending.exists(),
            "total_spent": group.expenses.aggregate(total=Sum("amount"))["total"] or 0,
        }
        return render(request, "groups/detail.html", context)


class GroupCreateView(LoginRequiredMixin, View):
    template_name = "groups/form.html"

    def get(self, request):
        return render(request, self.template_name, {"form": ExpenseGroupForm()})

    @transaction.atomic
    def post(self, request):
        form = ExpenseGroupForm(request.POST)
        if not form.is_valid():
            return render(request, self.template_name, {"form": form})
        group = form.save(commit=False)
        group.owner = request.user
        group.full_clean()
        group.save()
        Membership.objects.create(group=group, user=request.user, role=Membership.Role.OWNER)
        messages.success(request, "Grupo criado com sucesso.")
        return redirect("group-detail", pk=group.pk)


class ParticipantAddView(LoginRequiredMixin, View):
    def get(self, request, pk):
        group = get_member_group(request, pk)
        if group.owner_id != request.user.id:
            raise Http404
        form = ParticipantForm(group=group)
        return render(request, "groups/participant_form.html", {"form": form, "group": group})

    @transaction.atomic
    def post(self, request, pk):
        group = get_member_group(request, pk)
        group = ExpenseGroup.objects.select_for_update().get(pk=group.pk)
        if group.owner_id != request.user.id:
            raise Http404
        form = ParticipantForm(request.POST, group=group)
        if not form.is_valid():
            return render(request, "groups/participant_form.html", {"form": form, "group": group})
        Membership.objects.create(group=group, user=form.cleaned_data["username"], role=Membership.Role.MEMBER)
        messages.success(request, "Participante adicionado.")
        return redirect("group-detail", pk=group.pk)


class ParticipantRemoveView(LoginRequiredMixin, View):
    @transaction.atomic
    def post(self, request, pk, membership_id):
        group = get_member_group(request, pk)
        group = ExpenseGroup.objects.select_for_update().get(pk=group.pk)
        if group.owner_id != request.user.id:
            raise Http404
        membership = get_object_or_404(Membership, pk=membership_id, group=group)
        if membership.role == Membership.Role.OWNER:
            messages.error(request, "O responsável não pode ser removido.")
            return redirect("group-detail", pk=group.pk)
        if membership.expense_shares.exists() or membership.paid_expenses.exists() or membership.settlements_sent.exists() or membership.settlements_received.exists():
            messages.error(request, "Não é possível remover um participante com movimentações financeiras.")
            return redirect("group-detail", pk=group.pk)
        membership.delete()
        messages.success(request, "Participante removido.")
        return redirect("group-detail", pk=group.pk)
