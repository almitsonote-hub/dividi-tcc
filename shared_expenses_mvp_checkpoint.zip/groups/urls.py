from django.urls import path

from .views import GroupCreateView, GroupDetailView, ParticipantAddView, ParticipantRemoveView

urlpatterns = [
    path("novo/", GroupCreateView.as_view(), name="group-create"),
    path("<int:pk>/", GroupDetailView.as_view(), name="group-detail"),
    path("<int:pk>/participantes/novo/", ParticipantAddView.as_view(), name="participant-add"),
    path("<int:pk>/participantes/<int:membership_id>/remover/", ParticipantRemoveView.as_view(), name="participant-remove"),
]
