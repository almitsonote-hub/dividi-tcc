from django.contrib import admin

from .models import Category, Expense, ExpenseShare


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "active")
    prepopulated_fields = {"slug": ("name",)}


class ExpenseShareInline(admin.TabularInline):
    model = ExpenseShare
    extra = 0


@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    list_display = ("description", "group", "amount", "expense_date", "payer", "split_method")
    list_filter = ("split_method", "category")
    search_fields = ("description", "group__name")
    inlines = (ExpenseShareInline,)
