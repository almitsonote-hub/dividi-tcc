from django import forms
from django.core.exceptions import ValidationError

from .models import Category, Expense


class ExpenseBaseForm(forms.ModelForm):
    participant_ids = forms.CharField(widget=forms.HiddenInput(), required=False)

    class Meta:
        model = Expense
        fields = ("description", "amount", "expense_date", "category", "payer", "split_method", "notes")
        widgets = {
            "expense_date": forms.DateInput(attrs={"type": "date"}),
            "amount": forms.NumberInput(attrs={"step": "0.01", "min": "0.01"}),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, **kwargs):
        group = kwargs.pop("group")
        super().__init__(*args, **kwargs)
        self.group = group
        self.fields["category"].queryset = Category.objects.filter(active=True)
        self.fields["payer"].queryset = group.memberships.select_related("user")

    def clean_payer(self):
        payer = self.cleaned_data["payer"]
        if payer.group_id != self.group.id:
            raise ValidationError("Pagador inválido para o grupo.")
        return payer
