from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q

from core.models import TimeStampedModel
from groups.models import ExpenseGroup, Membership


class Category(TimeStampedModel):
    name = models.CharField(max_length=60, unique=True)
    slug = models.SlugField(max_length=60, unique=True)
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ("name",)
        verbose_name_plural = "Categories"

    def __str__(self):
        return self.name


class Expense(TimeStampedModel):
    class SplitMethod(models.TextChoices):
        EQUAL = "equal", "Igual"
        CUSTOM = "custom", "Personalizada"
        PERCENTAGE = "percentage", "Percentual"

    group = models.ForeignKey(ExpenseGroup, on_delete=models.CASCADE, related_name="expenses")
    description = models.CharField(max_length=180)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    expense_date = models.DateField()
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="expenses")
    payer = models.ForeignKey(Membership, on_delete=models.PROTECT, related_name="paid_expenses")
    split_method = models.CharField(max_length=12, choices=SplitMethod.choices)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey("auth.User", on_delete=models.PROTECT, related_name="created_expenses")

    class Meta:
        ordering = ("-expense_date", "-created_at")
        constraints = [
            models.CheckConstraint(condition=Q(amount__gt=Decimal("0.00")), name="expense_amount_positive"),
        ]

    def clean(self):
        errors = {}
        if self.amount <= 0:
            errors["amount"] = "O valor deve ser maior que zero."
        if self.payer_id and self.group_id and self.payer.group_id != self.group_id:
            errors["payer"] = "O pagador precisa pertencer ao grupo da despesa."
        if errors:
            raise ValidationError(errors)

    def __str__(self):
        return self.description


class ExpenseShare(TimeStampedModel):
    expense = models.ForeignKey(Expense, on_delete=models.CASCADE, related_name="shares")
    participant = models.ForeignKey(Membership, on_delete=models.PROTECT, related_name="expense_shares")
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    percentage = models.DecimalField(max_digits=7, decimal_places=2, blank=True, null=True)

    class Meta:
        ordering = ("participant__user__username", "id")
        constraints = [
            models.UniqueConstraint(fields=("expense", "participant"), name="unique_expense_participant"),
            models.CheckConstraint(condition=Q(amount__gt=Decimal("0.00")), name="share_amount_positive"),
            models.CheckConstraint(
                condition=Q(percentage__isnull=True) | Q(percentage__gte=Decimal("0.00"), percentage__lte=Decimal("100.00")),
                name="share_percentage_range",
            ),
        ]

    def clean(self):
        if self.participant_id and self.expense_id and self.participant.group_id != self.expense.group_id:
            raise ValidationError("O participante precisa pertencer ao grupo da despesa.")

    def __str__(self):
        return f"{self.expense} — {self.participant.user.get_username()}"
