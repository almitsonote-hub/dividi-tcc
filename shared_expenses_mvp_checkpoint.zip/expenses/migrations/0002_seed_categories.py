from django.db import migrations


CATEGORIES = [
    ("Alimentação", "alimentacao"),
    ("Transporte", "transporte"),
    ("Hospedagem", "hospedagem"),
    ("Compras", "compras"),
    ("Lazer", "lazer"),
    ("Contas", "contas"),
    ("Outros", "outros"),
]


def seed_categories(apps, schema_editor):
    Category = apps.get_model("expenses", "Category")
    for name, slug in CATEGORIES:
        Category.objects.get_or_create(name=name, defaults={"slug": slug, "active": True})


class Migration(migrations.Migration):
    dependencies = [("expenses", "0001_initial")]
    operations = [migrations.RunPython(seed_categories, migrations.RunPython.noop)]
