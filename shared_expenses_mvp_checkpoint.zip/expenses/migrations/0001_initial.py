from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
from decimal import Decimal


class Migration(migrations.Migration):
    initial = True
    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("groups", "0001_initial"),
    ]
    operations = [
        migrations.CreateModel(
            name="Category",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("name", models.CharField(max_length=60, unique=True)),
                ("slug", models.SlugField(max_length=60, unique=True)),
                ("active", models.BooleanField(default=True)),
            ],
            options={"ordering": ("name",), "verbose_name_plural": "Categories"},
        ),
        migrations.CreateModel(
            name="Expense",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("description", models.CharField(max_length=180)),
                ("amount", models.DecimalField(decimal_places=2, max_digits=12)),
                ("expense_date", models.DateField()),
                ("split_method", models.CharField(choices=[("equal", "Igual"), ("custom", "Personalizada"), ("percentage", "Percentual")], max_length=12)),
                ("notes", models.TextField(blank=True)),
                ("category", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="expenses", to="expenses.category")),
                ("created_by", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="created_expenses", to=settings.AUTH_USER_MODEL)),
                ("group", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="expenses", to="groups.expensegroup")),
                ("payer", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="paid_expenses", to="groups.membership")),
            ],
            options={"ordering": ("-expense_date", "-created_at")},
        ),
        migrations.CreateModel(
            name="ExpenseShare",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("amount", models.DecimalField(decimal_places=2, max_digits=12)),
                ("percentage", models.DecimalField(blank=True, decimal_places=2, max_digits=7, null=True)),
                ("expense", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="shares", to="expenses.expense")),
                ("participant", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="expense_shares", to="groups.membership")),
            ],
            options={"ordering": ("participant__user__username", "id")},
        ),
        migrations.AddConstraint(
            model_name="expense",
            constraint=models.CheckConstraint(condition=models.Q(("amount__gt", Decimal("0.00"))), name="expense_amount_positive"),
        ),
        migrations.AddConstraint(
            model_name="expenseshare",
            constraint=models.UniqueConstraint(fields=("expense", "participant"), name="unique_expense_participant"),
        ),
        migrations.AddConstraint(
            model_name="expenseshare",
            constraint=models.CheckConstraint(condition=models.Q(("amount__gt", Decimal("0.00"))), name="share_amount_positive"),
        ),
        migrations.AddConstraint(
            model_name="expenseshare",
            constraint=models.CheckConstraint(condition=models.Q(("percentage__isnull", True)) | (models.Q(("percentage__gte", Decimal("0.00"))) & models.Q(("percentage__lte", Decimal("100.00")))), name="share_percentage_range"),
        ),
    ]
