from decimal import Decimal, InvalidOperation

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.exceptions import ValidationError
from django.db import transaction
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views import View

from groups.models import ExpenseGroup, Membership
from settlements.models import Settlement

from .forms import ExpenseBaseForm
from .models import Expense
from .services import build_shares, create_expense, has_any_settlement, money


def get_member_group(request, pk):
    return get_object_or_404(ExpenseGroup, pk=pk, memberships__user=request.user)


def parse_decimal_map(post, prefix, ids):
    result = {}
    for pk in ids:
        raw = post.get(f"{prefix}_{pk}", "").strip()
        if not raw:
            continue
        try:
            result[int(pk)] = Decimal(raw.replace(",", "."))
        except InvalidOperation as exc:
            raise ValidationError(f"Valor inválido para o participante {pk}.") from exc
    return result


def parse_participant_ids(raw):
    ids = []
    for value in (raw or "").split(","):
        value = value.strip()
        if value:
            try:
                ids.append(int(value))
            except ValueError as exc:
                raise ValidationError("Lista de participantes inválida.") from exc
    return list(dict.fromkeys(ids))


class ExpenseCreateView(LoginRequiredMixin, View):
    def get(self, request, group_id):
        group = get_member_group(request, group_id)
        form = ExpenseBaseForm(group=group, initial={"expense_date": timezone.localdate(), "split_method": Expense.SplitMethod.EQUAL})
        return render(request, "expenses/form.html", self.context(group, form))

    @transaction.atomic
    def post(self, request, group_id):
        group = get_member_group(request, group_id)
        form = ExpenseBaseForm(request.POST, group=group)
        if not form.is_valid():
            return render(request, "expenses/form.html", self.context(group, form))
        try:
            participant_ids = parse_participant_ids(form.cleaned_data["participant_ids"])
            method = form.cleaned_data["split_method"]
            custom = parse_decimal_map(request.POST, "amount", participant_ids) if method == Expense.SplitMethod.CUSTOM else {}
            percentages = parse_decimal_map(request.POST, "percent", participant_ids) if method == Expense.SplitMethod.PERCENTAGE else {}
            create_expense(
                group=group,
                user=request.user,
                description=form.cleaned_data["description"],
                amount=form.cleaned_data["amount"],
                expense_date=form.cleaned_data["expense_date"],
                category=form.cleaned_data["category"],
                payer_id=form.cleaned_data["payer"].id,
                split_method=method,
                participant_ids=participant_ids,
                custom_values=custom,
                percentages=percentages,
                notes=form.cleaned_data["notes"],
            )
        except ValidationError as exc:
            form.add_error(None, exc)
            return render(request, "expenses/form.html", self.context(group, form))
        messages.success(request, "Despesa registrada.")
        return redirect("group-detail", pk=group.id)

    @staticmethod
    def context(group, form, selected_participant_ids=None, share_values=None):
        if selected_participant_ids is None:
            raw = form.data.get("participant_ids", "") if form.is_bound else ""
            try:
                selected_participant_ids = [int(value) for value in raw.split(",") if value]
            except ValueError:
                selected_participant_ids = []
        if share_values is None:
            share_values = {}
        return {
            "group": group,
            "form": form,
            "memberships": group.memberships.select_related("user"),
            "selected_participant_ids": selected_participant_ids,
            "share_values": share_values,
        }


class ExpenseEditView(LoginRequiredMixin, View):
    def get(self, request, pk):
        expense = get_object_or_404(Expense, pk=pk, group__memberships__user=request.user)
        group = expense.group
        if has_any_settlement(group):
            messages.error(request, "Despesas históricas não podem ser editadas depois que um acerto é registrado.")
            return redirect("expense-detail", pk=expense.pk)
        shares = expense.shares.in_bulk(field_name="participant_id")
        selected_ids = list(shares)
        share_values = {
            pk: {"amount": share.amount, "percentage": share.percentage} for pk, share in shares.items()
        }
        form = ExpenseBaseForm(
            group=group,
            instance=expense,
            initial={"participant_ids": ",".join(str(pk) for pk in selected_ids)},
        )
        return render(request, "expenses/form.html", ExpenseCreateView.context(group, form, selected_ids, share_values))

    @transaction.atomic
    def post(self, request, pk):
        expense = get_object_or_404(Expense, pk=pk, group__memberships__user=request.user)
        group = ExpenseGroup.objects.select_for_update().get(pk=expense.group_id)
        if has_any_settlement(group):
            messages.error(request, "Despesas históricas não podem ser editadas depois que um acerto é registrado.")
            return redirect("expense-detail", pk=expense.pk)
        form = ExpenseBaseForm(request.POST, group=group, instance=expense)
        if not form.is_valid():
            return render(request, "expenses/form.html", ExpenseCreateView.context(group, form))
        try:
            participant_ids = parse_participant_ids(form.cleaned_data["participant_ids"])
            method = form.cleaned_data["split_method"]
            custom = parse_decimal_map(request.POST, "amount", participant_ids) if method == Expense.SplitMethod.CUSTOM else {}
            percentages = parse_decimal_map(request.POST, "percent", participant_ids) if method == Expense.SplitMethod.PERCENTAGE else {}
            built = build_shares(group, form.cleaned_data["amount"], method, participant_ids, form.cleaned_data["payer"].id, custom, percentages)
            expense.description = form.cleaned_data["description"]
            expense.amount = money(form.cleaned_data["amount"])
            expense.expense_date = form.cleaned_data["expense_date"]
            expense.category = form.cleaned_data["category"]
            expense.payer = form.cleaned_data["payer"]
            expense.split_method = method
            expense.notes = form.cleaned_data["notes"]
            expense.save()
            expense.shares.all().delete()
            from .models import ExpenseShare
            ExpenseShare.objects.bulk_create([
                ExpenseShare(expense=expense, participant=membership, amount=share, percentage=pct)
                for _, (share, pct, membership) in built.items()
            ])
        except ValidationError as exc:
            form.add_error(None, exc)
            return render(request, "expenses/form.html", ExpenseCreateView.context(group, form))
        messages.success(request, "Despesa atualizada.")
        return redirect("expense-detail", pk=expense.pk)


class ExpenseListView(LoginRequiredMixin, View):
    def get(self, request, group_id):
        group = get_member_group(request, group_id)
        expenses = group.expenses.select_related("payer__user", "category").prefetch_related("shares__participant__user")
        return render(request, "expenses/list.html", {"group": group, "expenses": expenses})


class ExpenseDetailView(LoginRequiredMixin, View):
    def get(self, request, pk):
        expense = get_object_or_404(Expense.objects.select_related("group", "payer__user", "category"), pk=pk, group__memberships__user=request.user)
        shares = expense.shares.select_related("participant__user")
        return render(request, "expenses/detail.html", {"expense": expense, "shares": shares, "group": expense.group})


class ExpenseDeleteView(LoginRequiredMixin, View):
    @transaction.atomic
    def post(self, request, pk):
        expense = get_object_or_404(Expense, pk=pk, group__memberships__user=request.user)
        group = ExpenseGroup.objects.select_for_update().get(pk=expense.group_id)
        if has_any_settlement(group):
            messages.error(request, "Despesas históricas ficam protegidas depois que um acerto é registrado.")
            return redirect("expense-detail", pk=expense.pk)
        group_id = expense.group_id
        expense.delete()
        messages.success(request, "Despesa excluída.")
        return redirect("group-detail", pk=group_id)
