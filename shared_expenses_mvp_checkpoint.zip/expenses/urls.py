from django.urls import path

from .views import ExpenseCreateView, ExpenseDeleteView, ExpenseDetailView, ExpenseEditView, ExpenseListView

urlpatterns = [
    path("grupo/<int:group_id>/nova/", ExpenseCreateView.as_view(), name="expense-create"),
    path("grupo/<int:group_id>/", ExpenseListView.as_view(), name="expense-list"),
    path("<int:pk>/editar/", ExpenseEditView.as_view(), name="expense-edit"),
    path("<int:pk>/", ExpenseDetailView.as_view(), name="expense-detail"),
    path("<int:pk>/excluir/", ExpenseDeleteView.as_view(), name="expense-delete"),
]
