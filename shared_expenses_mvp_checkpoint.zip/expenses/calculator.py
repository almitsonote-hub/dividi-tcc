"""Pure money splitting rules. No Django dependency."""
from decimal import Decimal, ROUND_DOWN, ROUND_HALF_UP

MONEY_QUANTUM = Decimal("0.01")
PERCENT_QUANTUM = Decimal("0.01")


def money(value: Decimal | int | str) -> Decimal:
    return Decimal(value).quantize(MONEY_QUANTUM, rounding=ROUND_HALF_UP)


def _floor_money(value: Decimal) -> Decimal:
    return value.quantize(MONEY_QUANTUM, rounding=ROUND_DOWN)


def split_equal(total: Decimal, participant_ids: list[int]) -> dict[int, Decimal]:
    if not participant_ids:
        raise ValueError("Selecione ao menos um participante.")
    ids = sorted(set(int(pk) for pk in participant_ids))
    base = _floor_money(total / Decimal(len(ids)))
    shares = {pk: base for pk in ids}
    remaining_cents = int(((money(total) - base * len(ids)) / MONEY_QUANTUM).to_integral_value())
    for pk in ids[:remaining_cents]:
        shares[pk] += MONEY_QUANTUM
    return shares


def split_custom(total: Decimal, values: dict[int, Decimal]) -> dict[int, Decimal]:
    if not values:
        raise ValueError("Selecione ao menos um participante.")
    normalized = {int(pk): money(value) for pk, value in values.items()}
    if any(value <= 0 for value in normalized.values()):
        raise ValueError("Todas as parcelas selecionadas devem ser maiores que zero.")
    if sum(normalized.values(), Decimal("0.00")) != money(total):
        raise ValueError("A soma das parcelas personalizadas deve ser igual ao valor da despesa.")
    return normalized


def split_percentage(total: Decimal, percentages: dict[int, Decimal]) -> tuple[dict[int, Decimal], dict[int, Decimal]]:
    if not percentages:
        raise ValueError("Selecione ao menos um participante.")
    normalized_pct = {int(pk): Decimal(value).quantize(PERCENT_QUANTUM) for pk, value in percentages.items()}
    if any(value <= 0 for value in normalized_pct.values()):
        raise ValueError("Todos os percentuais selecionados devem ser maiores que zero.")
    if sum(normalized_pct.values(), Decimal("0.00")) != Decimal("100.00"):
        raise ValueError("A soma dos percentuais deve ser exatamente 100,00%.")

    raw = {pk: money(total) * pct / Decimal("100.00") for pk, pct in normalized_pct.items()}
    shares = {pk: _floor_money(value) for pk, value in raw.items()}
    allocated = sum(shares.values(), Decimal("0.00"))
    leftover_cents = int(((money(total) - allocated) / MONEY_QUANTUM).to_integral_value())
    ranking = sorted(raw, key=lambda pk: (raw[pk] - shares[pk], -pk), reverse=True)
    for pk in ranking[:leftover_cents]:
        shares[pk] += MONEY_QUANTUM
    return shares, normalized_pct
