from __future__ import annotations

from collections import defaultdict
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import transaction

from .models import Expense, ExpenseShare
from settlements.models import Settlement

from .calculator import money, split_custom, split_equal, split_percentage


def _validate_memberships(group, participant_ids, payer_id):
    ids = {int(pk) for pk in participant_ids}
    memberships = group.memberships.select_related("user").filter(id__in=ids)
    if memberships.count() != len(ids):
        raise ValidationError("Há participantes inválidos para este grupo.")
    if payer_id not in {m.id for m in memberships}:
        raise ValidationError("O pagador deve estar entre os participantes da despesa.")
    return {m.id: m for m in memberships}


def build_shares(group, amount: Decimal, split_method: str, participant_ids: list[int], payer_id: int, custom_values=None, percentages=None):
    memberships = _validate_memberships(group, participant_ids, payer_id)
    if split_method == Expense.SplitMethod.EQUAL:
        try:
            shares = split_equal(amount, list(memberships))
        except ValueError as exc:
            raise ValidationError(str(exc)) from exc
        pct = {pk: None for pk in shares}
    elif split_method == Expense.SplitMethod.CUSTOM:
        try:
            shares = split_custom(amount, custom_values or {})
        except ValueError as exc:
            raise ValidationError(str(exc)) from exc
        pct = {pk: None for pk in shares}
        if set(shares) != set(memberships):
            raise ValidationError("As parcelas personalizadas devem corresponder aos participantes selecionados.")
    elif split_method == Expense.SplitMethod.PERCENTAGE:
        try:
            shares, pct = split_percentage(amount, percentages or {})
        except ValueError as exc:
            raise ValidationError(str(exc)) from exc
        if set(shares) != set(memberships):
            raise ValidationError("Os percentuais devem corresponder aos participantes selecionados.")
    else:
        raise ValidationError("Método de divisão inválido.")

    if sum(shares.values(), Decimal("0.00")) != money(amount):
        raise ValidationError("A divisão gerou uma diferença financeira.")
    return {pk: (shares[pk], pct[pk], memberships[pk]) for pk in shares}


@transaction.atomic
def create_expense(*, group, user, description, amount, expense_date, category, payer_id, split_method, participant_ids, custom_values=None, percentages=None, notes=""):
    group = group.__class__.objects.select_for_update().get(pk=group.pk)
    if not group.memberships.filter(user=user).exists():
        raise ValidationError("Você não participa deste grupo.")
    amount = money(amount)
    built = build_shares(group, amount, split_method, participant_ids, int(payer_id), custom_values, percentages)
    expense = Expense(
        group=group,
        description=description.strip(),
        amount=amount,
        expense_date=expense_date,
        category=category,
        payer_id=payer_id,
        split_method=split_method,
        notes=notes.strip(),
        created_by=user,
    )
    expense.full_clean()
    expense.save()
    ExpenseShare.objects.bulk_create(
        [
            ExpenseShare(expense=expense, participant=membership, amount=share, percentage=pct)
            for _, (share, pct, membership) in built.items()
        ]
    )
    return expense


def has_any_settlement(group) -> bool:
    return group.settlements.exists()


def calculate_group_balances(group) -> dict:
    expense_balances = defaultdict(lambda: Decimal("0.00"))
    for expense in group.expenses.prefetch_related("shares").select_related("payer"):
        expense_balances[expense.payer_id] += money(expense.amount)
        for share in expense.shares.all():
            expense_balances[share.participant_id] -= money(share.amount)

    financial = defaultdict(lambda: Decimal("0.00"), expense_balances)
    for settlement in group.settlements.filter(status=Settlement.Status.PAID).select_related("payer", "receiver"):
        financial[settlement.payer_id] += money(-settlement.amount)
        financial[settlement.receiver_id] += money(settlement.amount)

    member_ids = list(group.memberships.values_list("id", flat=True))
    gross = {pk: money(expense_balances[pk]) for pk in member_ids}
    net = {pk: money(financial[pk]) for pk in member_ids}
    return {
        "expense_balances": gross,
        "financial_balances": net,
        "sum_expense_balances": money(sum(gross.values(), Decimal("0.00"))),
        "sum_financial_balances": money(sum(net.values(), Decimal("0.00"))),
    }


def recalculate_group(group):
    return calculate_group_balances(group)
