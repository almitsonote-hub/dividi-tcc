"""Reproducible algorithm evaluation scenarios for the academic report.

This script measures only the pure liquidation engine. It does not pretend to
measure network/database latency or user-facing performance.
"""
from __future__ import annotations

import sys
import time
from decimal import Decimal
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from settlements.engine import generate_liquidation, residual_balances


def build_balances(participants: int) -> dict[int, Decimal]:
    creditors_count = participants // 2
    creditors = []
    debtors = []

    # Deterministic cent-denominated values. The final debtor is normalized so
    # total credit equals total debt exactly.
    total_credit = Decimal("0.00")
    for index in range(1, creditors_count + 1):
        amount = Decimal(100 + index * 7)
        creditors.append((index, amount))
        total_credit += amount

    total_debt_except_last = Decimal("0.00")
    for offset in range(creditors_count):
        participant_id = creditors_count + offset + 1
        if offset == creditors_count - 1:
            amount = total_credit - total_debt_except_last
        else:
            amount = Decimal(55 + offset * 5)
            total_debt_except_last += amount
        debtors.append((participant_id, amount))
    balances = {pk: amount for pk, amount in creditors}
    balances.update({pk: -amount for pk, amount in debtors})
    return balances


def run_case(participants: int) -> dict[str, object]:
    balances = build_balances(participants)
    if sum(balances.values(), Decimal("0.00")) != Decimal("0.00"):
        raise AssertionError("Cenário inválido: saldos não fecham em zero.")

    start = time.perf_counter_ns()
    transfers = generate_liquidation(balances)
    elapsed_ns = time.perf_counter_ns() - start

    residual = residual_balances(balances, transfers)
    if any(value != Decimal("0.00") for value in residual.values()):
        raise AssertionError(f"Invariante quebrada para n={participants}: {residual}")

    total_sent = sum((item["amount"] for item in transfers), Decimal("0.00"))
    total_credit = sum((value for value in balances.values() if value > 0), Decimal("0.00"))
    return {
        "participants": participants,
        "transfers": len(transfers),
        "total_settled": str(total_sent),
        "expected_total": str(total_credit),
        "elapsed_microseconds": round(elapsed_ns / 1000, 2),
        "correct": True,
    }


if __name__ == "__main__":
    for participants in (3, 8, 15, 30):
        print(run_case(participants))
