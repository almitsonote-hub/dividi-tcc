import unittest
from decimal import Decimal

from expenses.calculator import split_custom, split_equal, split_percentage


class ExpenseCalculatorTests(unittest.TestCase):
    def test_equal_division_distributes_cent_deterministically(self):
        self.assertEqual(
            split_equal(Decimal("100.00"), [3, 1, 2]),
            {1: Decimal("33.34"), 2: Decimal("33.33"), 3: Decimal("33.33")},
        )

    def test_equal_division_single_cent(self):
        self.assertEqual(
            split_equal(Decimal("0.05"), [10, 20, 30]),
            {10: Decimal("0.02"), 20: Decimal("0.02"), 30: Decimal("0.01")},
        )

    def test_custom_division_requires_exact_sum(self):
        self.assertEqual(
            split_custom(Decimal("100.00"), {1: Decimal("40.00"), 2: Decimal("60.00")}),
            {1: Decimal("40.00"), 2: Decimal("60.00")},
        )
        with self.assertRaises(ValueError):
            split_custom(Decimal("100.00"), {1: Decimal("40.00"), 2: Decimal("59.99")})

    def test_percentage_division_exactly_sums_to_total(self):
        shares, percentages = split_percentage(Decimal("10.00"), {1: Decimal("33.33"), 2: Decimal("33.33"), 3: Decimal("33.34")})
        self.assertEqual(percentages[1], Decimal("33.33"))
        self.assertEqual(sum(shares.values()), Decimal("10.00"))
        self.assertEqual(shares, {1: Decimal("3.33"), 2: Decimal("3.33"), 3: Decimal("3.34")})

    def test_percentage_rounding_uses_largest_remainder(self):
        shares, _ = split_percentage(Decimal("0.05"), {1: Decimal("50.00"), 2: Decimal("30.00"), 3: Decimal("20.00")})
        self.assertEqual(sum(shares.values()), Decimal("0.05"))
