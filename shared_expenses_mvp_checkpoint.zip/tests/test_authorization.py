from datetime import date
from decimal import Decimal

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from expenses.models import Category, Expense
from expenses.services import create_expense
from groups.models import ExpenseGroup, Membership
from settlements.services import create_settlement


class AuthorizationTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.owner = User.objects.create_user(username="owner", password="x")
        cls.member = User.objects.create_user(username="member", password="x")
        cls.outsider = User.objects.create_user(username="outsider", password="x")

        cls.group_a = ExpenseGroup.objects.create(owner=cls.owner, name="Grupo A")
        cls.group_b = ExpenseGroup.objects.create(owner=cls.outsider, name="Grupo B")

        cls.owner_membership = Membership.objects.create(group=cls.group_a, user=cls.owner, role=Membership.Role.OWNER)
        cls.member_membership = Membership.objects.create(group=cls.group_a, user=cls.member)
        cls.outsider_membership = Membership.objects.create(group=cls.group_b, user=cls.outsider, role=Membership.Role.OWNER)

        cls.category = Category.objects.create(name="Transporte", slug="transporte-auth")
        cls.expense = create_expense(
            group=cls.group_a,
            user=cls.owner,
            description="Táxi",
            amount=Decimal("50.00"),
            expense_date=date(2026, 10, 1),
            category=cls.category,
            payer_id=cls.owner_membership.id,
            split_method=Expense.SplitMethod.EQUAL,
            participant_ids=[cls.owner_membership.id, cls.member_membership.id],
        )
        cls.settlement = create_settlement(
            group=cls.group_a,
            user=cls.owner,
            payer_id=cls.member_membership.id,
            receiver_id=cls.owner_membership.id,
            amount=Decimal("25.00"),
        )

    def test_member_cannot_view_other_group(self):
        self.client.force_login(self.member)
        response = self.client.get(reverse("group-detail", args=[self.group_b.id]))
        self.assertEqual(response.status_code, 404)

    def test_outsider_cannot_view_expense_by_id(self):
        self.client.force_login(self.outsider)
        response = self.client.get(reverse("expense-detail", args=[self.expense.id]))
        self.assertEqual(response.status_code, 404)

    def test_non_owner_cannot_add_participant(self):
        self.client.force_login(self.member)
        response = self.client.get(reverse("participant-add", args=[self.group_a.id]))
        self.assertEqual(response.status_code, 404)

    def test_outsider_cannot_mark_settlement_paid(self):
        self.client.force_login(self.outsider)
        response = self.client.post(reverse("settlement-mark-paid", args=[self.settlement.id]))
        self.assertEqual(response.status_code, 404)

    def test_expense_edit_is_blocked_after_settlement_exists(self):
        self.client.force_login(self.owner)
        response = self.client.post(
            reverse("expense-edit", args=[self.expense.id]),
            data={
                "description": "Tentativa",
                "amount": "50.00",
                "expense_date": "2026-10-01",
                "category": str(self.category.id),
                "payer": str(self.owner_membership.id),
                "split_method": "equal",
                "participant_ids": f"{self.owner_membership.id},{self.member_membership.id}",
                "notes": "",
            },
        )
        self.assertRedirects(response, reverse("expense-detail", args=[self.expense.id]))
        self.expense.refresh_from_db()
        self.assertEqual(self.expense.description, "Táxi")
