from datetime import date
from decimal import Decimal

from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.test import TestCase

from expenses.calculator import split_custom, split_equal, split_percentage
from expenses.models import Category, Expense
from expenses.services import calculate_group_balances, create_expense
from groups.models import ExpenseGroup, Membership
from settlements.engine import generate_liquidation, residual_balances
from settlements.services import create_settlement, current_liquidation, mark_paid


class DomainTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.users = [User.objects.create_user(username=name, password="x") for name in ("ana", "bruno", "carla", "diego")]
        cls.group = ExpenseGroup.objects.create(owner=cls.users[0], name="Teste")
        cls.members = [Membership.objects.create(group=cls.group, user=user, role=Membership.Role.OWNER if i == 0 else Membership.Role.MEMBER) for i, user in enumerate(cls.users)]
        cls.category = Category.objects.create(name="Alimentação", slug="alimentacao")

    def test_create_equal_expense_and_balance(self):
        create_expense(
            group=self.group,
            user=self.users[0],
            description="Jantar",
            amount=Decimal("100.00"),
            expense_date=date.today(),
            category=self.category,
            payer_id=self.members[0].id,
            split_method=Expense.SplitMethod.EQUAL,
            participant_ids=[m.id for m in self.members],
        )
        balances = calculate_group_balances(self.group)
        self.assertEqual(balances["sum_expense_balances"], Decimal("0.00"))
        self.assertEqual(balances["expense_balances"][self.members[0].id], Decimal("75.00"))

    def test_custom_and_percentage_validation(self):
        with self.assertRaises(ValueError):
            split_custom(Decimal("100.00"), {1: Decimal("50.00"), 2: Decimal("49.99")})
        with self.assertRaises(ValueError):
            split_percentage(Decimal("100.00"), {1: Decimal("40.00"), 2: Decimal("50.00")})
        self.assertEqual(sum(split_equal(Decimal("100.00"), [1, 2, 3]).values()), Decimal("100.00"))

    def test_liquidation_invariants_and_paid_settlement(self):
        create_expense(
            group=self.group,
            user=self.users[0],
            description="Conta",
            amount=Decimal("120.00"),
            expense_date=date.today(),
            category=self.category,
            payer_id=self.members[0].id,
            split_method=Expense.SplitMethod.EQUAL,
            participant_ids=[m.id for m in self.members],
        )
        balances, plan = current_liquidation(self.group)
        ids = [m.id for m in self.members]
        self.assertEqual(balances["sum_financial_balances"], Decimal("0.00"))
        self.assertTrue(all(v == 0 for v in residual_balances(balances["financial_balances"], plan).values()))
        item = plan[0]
        settlement = create_settlement(group=self.group, user=self.users[0], payer_id=item["payer_id"], receiver_id=item["receiver_id"], amount=item["amount"])
        self.assertEqual(settlement.status, "pending")
        mark_paid(settlement=settlement, user=self.users[0])
        self.assertEqual(self.group.settlements.get(pk=settlement.pk).status, "paid")

    def test_user_cannot_create_expense_in_other_group(self):
        outsider = User.objects.create_user(username="outsider", password="x")
        other = ExpenseGroup.objects.create(owner=outsider, name="Outro")
        other_member = Membership.objects.create(group=other, user=outsider)
        with self.assertRaises(ValidationError):
            create_expense(
                group=self.group,
                user=outsider,
                description="Invasão",
                amount=Decimal("10.00"),
                expense_date=date.today(),
                category=self.category,
                payer_id=self.members[0].id,
                split_method=Expense.SplitMethod.EQUAL,
                participant_ids=[m.id for m in self.members],
            )
        self.assertEqual(other_member.group_id, other.id)
