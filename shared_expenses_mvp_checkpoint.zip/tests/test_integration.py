from datetime import date
from decimal import Decimal

from django.contrib.auth.models import User
from django.test import TestCase

from expenses.models import Category, Expense
from expenses.services import calculate_group_balances, create_expense
from groups.models import ExpenseGroup, Membership
from settlements.engine import residual_balances
from settlements.services import create_settlement, current_liquidation, mark_paid


class IntegrationFlowTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.users = [User.objects.create_user(username=name, password="x") for name in ("ana", "bruno", "carla")]
        cls.group = ExpenseGroup.objects.create(owner=cls.users[0], name="Viagem")
        cls.members = [
            Membership.objects.create(group=cls.group, user=user, role=Membership.Role.OWNER if index == 0 else Membership.Role.MEMBER)
            for index, user in enumerate(cls.users)
        ]
        cls.category = Category.objects.create(name="Alimentação", slug="alimentacao-integration")

    def test_flow_expense_to_balance_to_settlement_to_paid(self):
        create_expense(
            group=self.group,
            user=self.users[0],
            description="Almoço",
            amount=Decimal("90.00"),
            expense_date=date(2026, 10, 1),
            category=self.category,
            payer_id=self.members[0].id,
            split_method=Expense.SplitMethod.EQUAL,
            participant_ids=[m.id for m in self.members],
        )
        balances = calculate_group_balances(self.group)
        self.assertEqual(balances["expense_balances"][self.members[0].id], Decimal("60.00"))
        self.assertEqual(balances["expense_balances"][self.members[1].id], Decimal("-30.00"))
        self.assertEqual(balances["expense_balances"][self.members[2].id], Decimal("-30.00"))

        _, plan = current_liquidation(self.group)
        self.assertEqual(len(plan), 2)
        self.assertEqual(sum((item["amount"] for item in plan), Decimal("0.00")), Decimal("60.00"))
        residual = residual_balances(balances["financial_balances"], plan)
        self.assertTrue(all(value == Decimal("0.00") for value in residual.values()))

        first = plan[0]
        settlement = create_settlement(
            group=self.group,
            user=self.users[0],
            payer_id=first["payer_id"],
            receiver_id=first["receiver_id"],
            amount=first["amount"],
        )
        _, remaining_plan = current_liquidation(self.group)
        self.assertEqual(sum((item["amount"] for item in remaining_plan), Decimal("0.00")), Decimal("60.00") - first["amount"])

        mark_paid(settlement=settlement, user=settlement.payer.user)
        balances_after = calculate_group_balances(self.group)
        self.assertEqual(balances_after["sum_financial_balances"], Decimal("0.00"))

    def test_all_split_modes_keep_exact_total(self):
        participants = [m.id for m in self.members]

        equal = create_expense(
            group=self.group,
            user=self.users[0],
            description="Igual",
            amount=Decimal("10.00"),
            expense_date=date(2026, 10, 1),
            category=self.category,
            payer_id=self.members[0].id,
            split_method=Expense.SplitMethod.EQUAL,
            participant_ids=participants,
        )
        custom = create_expense(
            group=self.group,
            user=self.users[0],
            description="Personalizada",
            amount=Decimal("10.01"),
            expense_date=date(2026, 10, 1),
            category=self.category,
            payer_id=self.members[0].id,
            split_method=Expense.SplitMethod.CUSTOM,
            participant_ids=participants,
            custom_values={self.members[0].id: Decimal("5.00"), self.members[1].id: Decimal("3.00"), self.members[2].id: Decimal("2.01")},
        )
        percentage = create_expense(
            group=self.group,
            user=self.users[0],
            description="Percentual",
            amount=Decimal("25.00"),
            expense_date=date(2026, 10, 1),
            category=self.category,
            payer_id=self.members[0].id,
            split_method=Expense.SplitMethod.PERCENTAGE,
            participant_ids=participants,
            percentages={self.members[0].id: Decimal("50.00"), self.members[1].id: Decimal("30.00"), self.members[2].id: Decimal("20.00")},
        )

        for expense, total in ((equal, Decimal("10.00")), (custom, Decimal("10.01")), (percentage, Decimal("25.00"))):
            self.assertEqual(sum(expense.shares.values_list("amount", flat=True), Decimal("0.00")), total)
