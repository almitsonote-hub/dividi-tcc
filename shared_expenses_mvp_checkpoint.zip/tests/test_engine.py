import unittest
from decimal import Decimal

from settlements.engine import generate_liquidation, residual_balances


class SettlementEngineTests(unittest.TestCase):
    def assert_balanced(self, balances):
        self.assertEqual(sum(balances.values(), Decimal("0.00")), Decimal("0.00"))

    def assert_settled(self, balances):
        transfers = generate_liquidation(balances)
        residual = residual_balances(balances, transfers)
        self.assertTrue(all(value == 0 for value in residual.values()), residual)
        self.assert_balanced(balances)
        self.assertEqual(
            sum(t["amount"] for t in transfers),
            sum(value for value in balances.values() if value > 0),
        )
        return transfers

    def test_one_debtor_two_creditors(self):
        transfers = self.assert_settled({1: Decimal("100.00"), 2: Decimal("50.00"), 3: Decimal("-150.00")})
        self.assertEqual(transfers, [
            {"payer_id": 3, "receiver_id": 1, "amount": Decimal("100.00")},
            {"payer_id": 3, "receiver_id": 2, "amount": Decimal("50.00")},
        ])

    def test_two_debtors_one_creditor(self):
        transfers = self.assert_settled({1: Decimal("-60.00"), 2: Decimal("-40.00"), 3: Decimal("100.00")})
        self.assertEqual(transfers, [
            {"payer_id": 1, "receiver_id": 3, "amount": Decimal("60.00")},
            {"payer_id": 2, "receiver_id": 3, "amount": Decimal("40.00")},
        ])

    def test_three_parties_mixed(self):
        self.assert_settled({1: Decimal("25.00"), 2: Decimal("-10.00"), 3: Decimal("-15.00")})

    def test_zero_and_ten_participants(self):
        balances = {i: Decimal("0.00") for i in range(1, 11)}
        self.assertEqual(generate_liquidation(balances), [])

    def test_deterministic_tie_break(self):
        balances = {1: Decimal("50.00"), 2: Decimal("50.00"), 3: Decimal("-100.00")}
        first = generate_liquidation(balances)
        second = generate_liquidation(balances)
        self.assertEqual(first, second)
        self.assertEqual(first[0]["receiver_id"], 1)

    def test_cent_precision(self):
        self.assert_settled({1: Decimal("0.03"), 2: Decimal("-0.01"), 3: Decimal("-0.02")})
