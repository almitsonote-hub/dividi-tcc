from django.contrib.auth.views import LoginView
from django.urls import path

from .views import SignUpView, UserLogoutView

urlpatterns = [
    path("entrar/", LoginView.as_view(template_name="registration/login.html"), name="login"),
    path("sair/", UserLogoutView.as_view(), name="logout"),
    path("cadastro/", SignUpView.as_view(), name="signup"),
]
