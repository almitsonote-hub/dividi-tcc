from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q

from core.models import TimeStampedModel
from groups.models import ExpenseGroup, Membership


class Settlement(TimeStampedModel):
    class Status(models.TextChoices):
        PENDING = "pending", "Pendente"
        PAID = "paid", "Pago"

    group = models.ForeignKey(ExpenseGroup, on_delete=models.CASCADE, related_name="settlements")
    payer = models.ForeignKey(Membership, on_delete=models.PROTECT, related_name="settlements_sent")
    receiver = models.ForeignKey(Membership, on_delete=models.PROTECT, related_name="settlements_received")
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    due_date = models.DateField(blank=True, null=True)
    paid_at = models.DateTimeField(blank=True, null=True)
    created_by = models.ForeignKey("auth.User", on_delete=models.PROTECT, related_name="created_settlements")

    class Meta:
        ordering = ("status", "due_date", "created_at")
        constraints = [
            models.CheckConstraint(condition=Q(amount__gt=0), name="settlement_amount_positive"),
        ]

    def clean(self):
        errors = {}
        if self.payer_id and self.receiver_id and self.payer_id == self.receiver_id:
            errors["receiver"] = "Pagador e recebedor precisam ser pessoas diferentes."
        if self.payer_id and self.group_id and self.payer.group_id != self.group_id:
            errors["payer"] = "Pagador inválido para o grupo."
        if self.receiver_id and self.group_id and self.receiver.group_id != self.group_id:
            errors["receiver"] = "Recebedor inválido para o grupo."
        if self.status == self.Status.PAID and self.paid_at is None:
            errors["paid_at"] = "Um acerto pago precisa registrar a data de pagamento."
        if self.status == self.Status.PENDING and self.paid_at is not None:
            errors["paid_at"] = "Um acerto pendente não deve possuir data de pagamento."
        if errors:
            raise ValidationError(errors)

    def __str__(self):
        return f"{self.payer.user.get_username()} → {self.receiver.user.get_username()}"
