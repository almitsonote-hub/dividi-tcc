from django import forms

from groups.models import Membership


class SettlementForm(forms.Form):
    payer = forms.ModelChoiceField(queryset=Membership.objects.none(), label="Quem paga")
    receiver = forms.ModelChoiceField(queryset=Membership.objects.none(), label="Quem recebe")
    amount = forms.DecimalField(max_digits=12, decimal_places=2, min_value=0.01, label="Valor", widget=forms.NumberInput(attrs={"step": "0.01", "min": "0.01"}))
    due_date = forms.DateField(required=False, label="Data prevista", widget=forms.DateInput(attrs={"type": "date"}))

    def __init__(self, *args, **kwargs):
        group = kwargs.pop("group")
        super().__init__(*args, **kwargs)
        qs = group.memberships.select_related("user")
        self.fields["payer"].queryset = qs
        self.fields["receiver"].queryset = qs

    def clean(self):
        cleaned = super().clean()
        if cleaned.get("payer") and cleaned.get("receiver") and cleaned["payer"] == cleaned["receiver"]:
            raise forms.ValidationError("Pagador e recebedor precisam ser diferentes.")
        return cleaned
