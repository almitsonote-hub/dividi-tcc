from django.urls import path
from .views import SettlementListView, SettlementMarkPaidView

urlpatterns = [
    path("grupo/<int:group_id>/", SettlementListView.as_view(), name="settlement-list"),
    path("<int:pk>/pagar/", SettlementMarkPaidView.as_view(), name="settlement-paid"),
]
