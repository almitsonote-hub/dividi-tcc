"""Pure settlement algorithm, independent from Django and the web layer."""
from decimal import Decimal, ROUND_HALF_UP

MONEY_QUANTUM = Decimal("0.01")


def money(value: Decimal | int | str) -> Decimal:
    return Decimal(value).quantize(MONEY_QUANTUM, rounding=ROUND_HALF_UP)


def generate_liquidation(balances: dict[int, Decimal]) -> list[dict]:
    """Generate a deterministic greedy settlement plan.

    Positive balances receive money; negative balances pay money. Ties use the
    membership id to keep output deterministic for the same input.
    """
    creditors = [[pk, money(value)] for pk, value in balances.items() if value > 0]
    debtors = [[pk, money(abs(value))] for pk, value in balances.items() if value < 0]
    creditors.sort(key=lambda item: (-item[1], item[0]))
    debtors.sort(key=lambda item: (-item[1], item[0]))

    result: list[dict] = []
    ci = di = 0
    while ci < len(creditors) and di < len(debtors):
        receiver, receive_amount = creditors[ci]
        payer, pay_amount = debtors[di]
        transfer = money(min(receive_amount, pay_amount))
        result.append({"payer_id": payer, "receiver_id": receiver, "amount": transfer})
        creditors[ci][1] = money(receive_amount - transfer)
        debtors[di][1] = money(pay_amount - transfer)
        if creditors[ci][1] == 0:
            ci += 1
        if debtors[di][1] == 0:
            di += 1
    return result


def residual_balances(balances: dict[int, Decimal], transfers: list[dict]) -> dict[int, Decimal]:
    residual = {pk: money(value) for pk, value in balances.items()}
    for item in transfers:
        amount = money(item["amount"])
        residual[item["payer_id"]] = money(residual[item["payer_id"]] + amount)
        residual[item["receiver_id"]] = money(residual[item["receiver_id"]] - amount)
    return residual
