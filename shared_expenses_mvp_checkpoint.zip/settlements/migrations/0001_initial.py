from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True
    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("groups", "0001_initial"),
    ]
    operations = [
        migrations.CreateModel(
            name="Settlement",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("amount", models.DecimalField(decimal_places=2, max_digits=12)),
                ("status", models.CharField(choices=[("pending", "Pendente"), ("paid", "Pago")], default="pending", max_length=10)),
                ("due_date", models.DateField(blank=True, null=True)),
                ("paid_at", models.DateTimeField(blank=True, null=True)),
                ("created_by", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="created_settlements", to=settings.AUTH_USER_MODEL)),
                ("group", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="settlements", to="groups.expensegroup")),
                ("payer", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="settlements_sent", to="groups.membership")),
                ("receiver", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="settlements_received", to="groups.membership")),
            ],
            options={"ordering": ("status", "due_date", "created_at")},
        ),
        migrations.AddConstraint(
            model_name="settlement",
            constraint=models.CheckConstraint(condition=models.Q(("amount__gt", 0)), name="settlement_amount_positive"),
        ),
    ]
