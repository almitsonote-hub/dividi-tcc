from __future__ import annotations

from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from expenses.services import calculate_group_balances, money
from .engine import generate_liquidation
from .models import Settlement


def registered_settlements(group):
    return group.settlements.select_related("payer__user", "receiver__user").order_by("-created_at")


def pending_commitments(group):
    return group.settlements.filter(status=Settlement.Status.PENDING).select_related("payer__user", "receiver__user")


def remaining_balances_for_liquidation(group):
    balances = calculate_group_balances(group)["financial_balances"].copy()
    for settlement in group.settlements.filter(status=Settlement.Status.PENDING):
        balances[settlement.payer_id] = money(balances.get(settlement.payer_id, 0) + settlement.amount)
        balances[settlement.receiver_id] = money(balances.get(settlement.receiver_id, 0) - settlement.amount)
    return balances


def current_liquidation(group):
    balances = calculate_group_balances(group)
    planned_balances = remaining_balances_for_liquidation(group)
    transfers = generate_liquidation(planned_balances)
    names = dict(group.memberships.values_list("id", "user__username"))
    for item in transfers:
        item["payer_name"] = names[item["payer_id"]]
        item["receiver_name"] = names[item["receiver_id"]]
    return balances, transfers


def _directional_remaining(group, payer_id: int, receiver_id: int) -> Decimal:
    balances = remaining_balances_for_liquidation(group)
    payer_balance = money(balances.get(payer_id, 0))
    receiver_balance = money(balances.get(receiver_id, 0))
    if payer_balance >= 0 or receiver_balance <= 0:
        return Decimal("0.00")
    return min(payer_balance.copy_abs(), receiver_balance)


@transaction.atomic
def create_settlement(*, group, user, payer_id, receiver_id, amount, due_date=None):
    group = group.__class__.objects.select_for_update().get(pk=group.pk)
    if not group.memberships.filter(user=user).exists():
        raise ValidationError("Você não participa deste grupo.")
    payer = group.memberships.filter(pk=payer_id).first()
    receiver = group.memberships.filter(pk=receiver_id).first()
    if not payer or not receiver:
        raise ValidationError("Participante inválido para este grupo.")
    if payer.id == receiver.id:
        raise ValidationError("Pagador e recebedor precisam ser diferentes.")
    if user.id not in {payer.user_id, receiver.user_id, group.owner_id}:
        raise ValidationError("Só o pagador, o recebedor ou o responsável pode registrar este acerto.")
    amount = money(amount)
    if amount <= 0:
        raise ValidationError("O valor do acerto deve ser maior que zero.")
    remaining = _directional_remaining(group, payer.id, receiver.id)
    if amount > remaining:
        raise ValidationError("O valor excede o saldo atualmente necessário nessa direção.")
    settlement = Settlement(
        group=group,
        payer=payer,
        receiver=receiver,
        amount=amount,
        due_date=due_date,
        created_by=user,
    )
    settlement.full_clean()
    settlement.save()
    return settlement


@transaction.atomic
def mark_paid(*, settlement, user):
    # Lock the group first, matching create_expense/create_settlement, then the settlement.
    group = settlement.group.__class__.objects.select_for_update().get(pk=settlement.group_id)
    settlement = Settlement.objects.select_for_update().select_related("group", "payer__user", "receiver__user").get(pk=settlement.pk)
    if not settlement.group.memberships.filter(user=user).exists():
        raise ValidationError("Você não participa deste grupo.")
    if user.id not in {settlement.payer.user_id, settlement.receiver.user_id}:
        raise ValidationError("Só o pagador ou o recebedor pode marcar este acerto como pago.")
    if settlement.status == Settlement.Status.PAID:
        return settlement
    settlement.status = Settlement.Status.PAID
    settlement.paid_at = timezone.now()
    settlement.save(update_fields=("status", "paid_at", "updated_at"))
    return settlement
