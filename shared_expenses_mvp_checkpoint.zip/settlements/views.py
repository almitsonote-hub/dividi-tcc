from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.exceptions import ValidationError
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.views import View

from groups.models import ExpenseGroup

from .forms import SettlementForm
from .models import Settlement
from .services import create_settlement, current_liquidation, mark_paid


class SettlementListView(LoginRequiredMixin, View):
    def get(self, request, group_id):
        group = get_object_or_404(ExpenseGroup, pk=group_id, memberships__user=request.user)
        balances, liquidation = current_liquidation(group)
        settlements = group.settlements.select_related("payer__user", "receiver__user").order_by("status", "-created_at")
        form = SettlementForm(group=group)
        return render(request, "settlements/list.html", {
            "group": group,
            "balances": balances,
            "liquidation": liquidation,
            "settlements": settlements,
            "form": form,
        })

    @transaction.atomic
    def post(self, request, group_id):
        group = get_object_or_404(ExpenseGroup, pk=group_id, memberships__user=request.user)
        form = SettlementForm(request.POST, group=group)
        if not form.is_valid():
            balances, liquidation = current_liquidation(group)
            settlements = group.settlements.select_related("payer__user", "receiver__user").order_by("status", "-created_at")
            return render(request, "settlements/list.html", {"group": group, "balances": balances, "liquidation": liquidation, "settlements": settlements, "form": form})
        try:
            settlement = create_settlement(
                group=group,
                user=request.user,
                payer_id=form.cleaned_data["payer"].id,
                receiver_id=form.cleaned_data["receiver"].id,
                amount=form.cleaned_data["amount"],
                due_date=form.cleaned_data["due_date"],
            )
        except ValidationError as exc:
            form.add_error(None, exc)
            balances, liquidation = current_liquidation(group)
            settlements = group.settlements.select_related("payer__user", "receiver__user").order_by("status", "-created_at")
            return render(request, "settlements/list.html", {"group": group, "balances": balances, "liquidation": liquidation, "settlements": settlements, "form": form})
        messages.success(request, f"Acerto registrado: {settlement.payer.user.get_username()} → {settlement.receiver.user.get_username()}.")
        return redirect("settlement-list", group_id=group.id)


class SettlementMarkPaidView(LoginRequiredMixin, View):
    @transaction.atomic
    def post(self, request, pk):
        settlement = get_object_or_404(Settlement, pk=pk, group__memberships__user=request.user)
        try:
            mark_paid(settlement=settlement, user=request.user)
        except ValidationError as exc:
            messages.error(request, exc.message)
        else:
            messages.success(request, "Acerto marcado como pago.")
        return redirect("settlement-list", group_id=settlement.group_id)
