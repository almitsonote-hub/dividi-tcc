# Especificação técnica consolidada

## Objetivo

Disponibilizar uma aplicação Django para registrar despesas compartilhadas, calcular saldos e gerar uma estratégia de liquidação auditável e determinística.

## Arquitetura

Monólito modular Django com renderização server-side, PostgreSQL como banco padrão e JavaScript vanilla apenas para comportamento de formulários.

Módulos:

- `accounts`: autenticação e cadastro;
- `groups`: grupos e memberships;
- `expenses`: despesas, parcelas e cálculo;
- `settlements`: acertos e liquidação;
- `core`: dashboard e componentes compartilhados.

## Fontes de verdade

Despesas e parcelas são persistidas. Saldos e liquidação são derivados em tempo de consulta. O objetivo é evitar colunas financeiras derivadas que possam divergir das fontes de verdade.

## Regras financeiras

```text
saldo_bruto = pagamentos de despesas - parcelas devidas
saldo_financeiro = saldo_bruto - acertos pagos enviados + acertos pagos recebidos
```

A soma dos saldos deve permanecer `0.00`.

## Divisão

- Igual: centavos restantes vão para os primeiros IDs na ordem determinística.
- Personalizada: soma das parcelas deve ser exatamente o total.
- Percentual: soma dos percentuais deve ser exatamente `100.00%`; centavos restantes seguem o maior resto fracionário, com ID como desempate.

## Liquidação

Separar devedores e credores, ordenar de forma determinística, transferir o menor entre dívida e crédito e repetir até zerar todos. Complexidade dominante `O(n log n)`.

## Controle de histórico

Quando há qualquer acerto registrado, edições e exclusões de despesas são bloqueadas no MVP. O sistema evita que uma edição retroativa torne um acerto histórico inexplicável.

## Aceitação

O MVP exige aplicação inicializável, migrations, autenticação, grupos, participantes, três métodos de divisão, saldos, liquidação, acertos, dashboard, isolamento de acesso, responsividade e testes das regras críticas.

## Estado desta especificação

Consolidada para o desenvolvimento do checkpoint atual. Resultados de execução permanecem separados da especificação e são registrados em `STATUS.md`.
