# Plano de testes

## Camada pura

Arquivos: `tests/test_calculator.py` e `tests/test_engine.py`.

Cobertura:

- divisão igual;
- centavos restantes;
- divisão personalizada;
- divisão percentual;
- invariantes do motor;
- determinismo;
- zeros;
- cenários com centavos.

## Django

`tests/test_django_domain.py` cobre:

- persistência de despesa;
- saldo bruto;
- validação de divisão;
- criação/pagamento de acerto;
- isolamento de grupos no serviço.

`tests/test_authorization.py` cobre:

- acesso legítimo a grupo;
- isolamento entre grupos;
- manipulação de IDs de despesas/acertos;
- privilégio de responsável;
- bloqueio de edição histórica após acerto.

`tests/test_integration.py` cobre:

- fluxo despesa → saldo → liquidação;
- registro de acerto pendente;
- reserva de acerto pendente no plano corrente;
- marcação como pago;
- três métodos de divisão preservando o total.

## Avaliação do algoritmo

`tests/evaluate_algorithm.py` cria cenários determinísticos com 3, 8, 15 e 30 participantes e verifica correção, saldo residual e volume de transferências. O tempo medido é somente da função pura no ambiente em que o script for executado.

## Casos extremos planejados

- 2 participantes;
- 3 participantes;
- 10 participantes;
- 30 participantes;
- uma pessoa pagando tudo;
- múltiplos pagadores;
- um devedor;
- múltiplos devedores;
- múltiplos credores;
- múltiplas despesas;
- valores pequenos;
- valores grandes;
- centavos;
- percentuais;
- divisões personalizadas.

## Critério

Nenhum resultado é considerado aprovado sem execução real do teste. Métricas experimentais do TCC devem ser copiadas apenas de execuções efetivamente realizadas e registradas pela equipe.
