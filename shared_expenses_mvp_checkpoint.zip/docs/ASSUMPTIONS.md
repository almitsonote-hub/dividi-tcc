# Assunções e decisões

## Identidade

O MVP utiliza somente usuários registrados como participantes. Isso elimina ambiguidades de identidade e simplifica autorização e histórico.

## Moeda

Cada grupo usa uma única moeda. Não há conversão cambial no MVP.

## Dinheiro

Valores usam `Decimal`/`DecimalField` com duas casas monetárias. Nunca usar `float` para dinheiro.

## Arredondamento

Política única: `ROUND_HALF_UP` para quantização monetária; nas divisões, o cálculo é feito com precisão decimal e os centavos restantes são distribuídos por uma regra determinística documentada em `docs/ALGORITHM.md`.

## Saldos

`saldo_bruto = pagos - devido`. O `saldo_financeiro` adicionalmente incorpora acertos já pagos.

## Acertos pendentes

Acertos pendentes funcionam como compromissos registrados e são descontados do plano corrente para evitar duplicação de transferências.

## Histórico

Depois que qualquer acerto existe no grupo, edição ou exclusão de despesas é bloqueada no MVP. Isso preserva a explicabilidade do histórico sem exigir um mecanismo complexo de reversão.

## Participantes

O responsável não pode ser removido. Participantes com movimentações financeiras não podem ser removidos.

## Liquidação

O MVP usa algoritmo guloso, determinístico e explicável. Não afirma minimalidade global do número de transações.

## Segurança

Autorização ocorre no backend e é baseada em membership. IDs enviados pelo cliente não são considerados prova de acesso.

## Extensões

IA, relatórios avançados, exportações e integrações permanecem fora do núcleo do MVP.
