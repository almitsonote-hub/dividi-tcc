# Algoritmo de divisão e liquidação

## Arredondamento

A unidade monetária é centavo (`0.01`).

### Divisão igual

1. ordenar IDs dos participantes;
2. calcular parcela-base truncada a centavos;
3. calcular centavos restantes;
4. adicionar um centavo às primeiras posições da ordem determinística.

### Divisão percentual

1. validar soma em `100,00%`;
2. calcular valor bruto de cada participação;
3. truncar cada valor a centavos;
4. medir o restante;
5. entregar centavos restantes pelas maiores partes fracionárias;
6. em empate, usar `Membership.id` como desempate.

## Saldo

Para cada participante:

```text
saldo_bruto = pagamentos_de_despesas - parcelas_devidas
saldo_financeiro = saldo_bruto - acertos_pagos_enviados + acertos_pagos_recebidos
```

A fórmula implementada é:

```text
saldo_financeiro = saldo_bruto - acertos_pagos_enviados + acertos_pagos_recebidos
```

Logo:

- saldo positivo: recebe;
- saldo negativo: paga;
- zero: equilibrado.

## Liquidação gulosa

Entrada:

```text
{membership_id: saldo}
```

1. credores = saldos positivos;
2. devedores = saldos negativos;
3. ordenar por maior valor absoluto e ID como desempate;
4. transferir `min(dívida, crédito)`;
5. zerar quem atingir zero;
6. repetir.

Complexidade da etapa de ordenação: `O(n log n)`. A fase de pareamento percorre as duas listas em ordem linear, portanto a ordem dominante é `O(n log n)`.

## Invariantes

```text
sum(saldos) == 0
```

```text
sum(valores enviados) == sum(valores recebidos)
```

Após aplicar todas as transferências:

```text
saldo residual de todos == 0
```

## Limitações

A estratégia é explicável e determinística. Ela não é declarada como solução global de menor número de transações.
