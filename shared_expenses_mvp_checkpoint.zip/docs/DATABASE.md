# Banco de dados

## Entidades

`auth_user` — identidade do usuário.

`groups_expensegroup` — grupo e sua moeda/período.

`groups_membership` — associação usuário ↔ grupo, com papel.

`expenses_category` — categorias controladas pelo seed/admin.

`expenses_expense` — despesa, pagador, método de divisão e metadados.

`expenses_expenseshare` — parcela de cada participante.

`settlements_settlement` — transferência registrada, pendente ou paga.

## Integridade

- usuário só participa uma vez de cada grupo;
- participante de uma parcela deve pertencer ao grupo da despesa;
- pagador deve pertencer ao grupo;
- valores de despesa e acerto são positivos;
- percentuais ficam entre 0 e 100;
- acertos não permitem pagador igual ao recebedor via validação de domínio;
- exclusão de usuários com impacto financeiro é protegida por `PROTECT` nos relacionamentos críticos.

## Derivados

Saldos não são persistidos. Isso evita divergência entre dados-base e colunas calculadas.
