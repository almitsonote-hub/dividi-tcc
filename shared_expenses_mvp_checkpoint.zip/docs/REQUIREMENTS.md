# Requisitos

## Funcionais

| ID | Requisito | MVP | Critério de aceitação |
|---|---|---:|---|
| RF01 | Cadastrar usuário | Sim | novo usuário consegue autenticar |
| RF02 | Autenticar usuário | Sim | sessão Django é criada e encerrada |
| RF03 | Criar grupo | Sim | grupo cria membership do responsável |
| RF04 | Adicionar participante | Sim | responsável adiciona usuário existente |
| RF05 | Cadastrar despesa | Sim | despesa persiste com pagador e participantes |
| RF06 | Dividir despesa | Sim | igual, personalizada e percentual produzem soma exata |
| RF07 | Calcular saldo | Sim | soma dos saldos é zero |
| RF08 | Gerar liquidação | Sim | devedores e credores são zerados |
| RF09 | Registrar acerto | Sim | transferência é persistida como pendente |
| RF10 | Marcar acerto como pago | Sim | status e `paid_at` são persistidos |
| RF11 | Dashboard | Sim | dados são derivados do banco autorizado |
| RF12 | Histórico | Sim | despesas e acertos podem ser consultados |

## Não funcionais

- RNF01: valores monetários sem `float`;
- RNF02: autorização server-side;
- RNF03: proteção CSRF;
- RNF04: responsividade;
- RNF05: foco visível e formulários sem depender apenas de cor;
- RNF06: operações críticas atômicas quando múltiplas tabelas são alteradas;
- RNF07: documentação sincronizada com código e testes.

## Rastreabilidade

RF07 → `expenses.services.calculate_group_balances` → testes de domínio + testes puros.

RF08 → `settlements.engine.generate_liquidation` → `tests/test_engine.py`.

RF06 → `expenses.calculator` → `tests/test_calculator.py`.
