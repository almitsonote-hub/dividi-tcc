# Acessibilidade

Medidas implementadas no MVP:

- HTML semântico;
- labels associados a campos;
- mensagens de erro textuais;
- foco visível;
- navegação funcional por teclado;
- contraste considerado na paleta;
- conteúdo não depende apenas de cor;
- preferência `prefers-reduced-motion` respeitada;
- tabelas com cabeçalhos;
- viewport responsivo;
- botões com área mínima de interação adequada a telas menores.

Ainda requer validação manual com teclado e leitores de tela antes do encerramento do projeto.
