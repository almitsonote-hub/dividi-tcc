# Guia de demonstração

1. Acesse o dashboard com uma conta da demonstração.
2. Abra `Viagem para São Paulo`.
3. Consulte os participantes e despesas recentes.
4. Abra uma despesa para mostrar o pagador e as parcelas.
5. Abra `Acertos` para mostrar a liquidação calculada.
6. Registre um acerto pendente.
7. Marque o acerto como pago.
8. Retorne ao grupo e mostre a atualização do saldo/liquidação.

Credenciais locais: ver `README.md`.
