# Avaliação de usabilidade

Este documento define o protocolo para uma avaliação futura do MVP. Nenhum resultado experimental é declarado aqui sem coleta real.

## Tarefas

1. Criar um grupo.
2. Adicionar participantes.
3. Registrar uma despesa.
4. Dividir o valor.
5. Descobrir quem deve pagar quem.
6. Registrar um acerto e marcá-lo como pago.

## Métricas planejadas

| Métrica | Resultado |
|---|---|
| Tempo por tarefa | [INSERIR DADO REAL] |
| Taxa de conclusão | [INSERIR DADO REAL] |
| Erros observados | [INSERIR DADO REAL] |
| Dúvidas recorrentes | [INSERIR DADO REAL] |
| Dificuldade percebida | [INSERIR DADO REAL] |

## Método

Registrar participante, tarefa, tempo de início/fim, erros e observações. Os dados devem ser coletados pela equipe e mantidos separados de dados fictícios do seed.

## Estado

**PLANEJADO.** A avaliação não foi realizada no ambiente de desenvolvimento deste checkpoint.
