# Arquitetura

## Estilo

Monólito modular Django, com server-side rendering e JavaScript apenas para comportamento de formulário.

## Módulos

### `accounts`
Cadastro e autenticação com `django.contrib.auth`.

### `groups`
Entidade `ExpenseGroup` e `Membership`. A relação membership é a fronteira de autorização do domínio.

### `expenses`
Categorias, despesas, parcelas de divisão e regras de cálculo.

### `settlements`
Registro de acertos e algoritmo de liquidação. `settlements/engine.py` não depende de Django para tornar o algoritmo isolável e testável.

### `core`
Dashboard e infraestrutura compartilhada.

## Fluxo de cálculo

```text
Expense + ExpenseShare
        ↓
   saldo bruto
        ↓
acertos pagos
        ↓
saldo financeiro
        ↓
acertos pendentes reservados
        ↓
motor guloso
        ↓
transferências sugeridas
```

Saldos não são armazenados como colunas derivadas no banco; são calculados a partir das fontes de verdade.

## Transações

Criação/edição/exclusão de despesas, criação de grupos, gestão de participantes e criação/pagamento de acertos usam `transaction.atomic` onde existe uma sequência de mudanças que precisa ser indivisível.

## Autorização

Views usam queries com `memberships__user=request.user` ou equivalente. Identificadores fornecidos pela URL não são suficientes para obter objetos financeiros.
