# Segurança

## Controles aplicados

- autenticação Django;
- hash seguro de senha via Django;
- CSRF middleware;
- sessões Django;
- validação server-side;
- autorização por membership;
- queries com escopo do grupo;
- secrets por variável de ambiente;
- `X-Frame-Options: DENY`;
- `SECURE_CONTENT_TYPE_NOSNIFF`;
- HSTS e cookies seguros quando `DEBUG=0`;
- transações para operações financeiras compostas.

## IDOR

Endpoints de grupo, despesa e acerto usam queries limitadas à relação `memberships__user=request.user`. Trocar um ID na URL não deve revelar outro grupo.

## Limitação

O ambiente do TCC deve configurar HTTPS real, secret forte e credenciais de banco fora do repositório. O projeto não declara conformidade legal ou certificação de segurança.
