# Roadmap

## P1

Somente após MVP estável:

- relatórios por categoria/participante/período;
- exportação CSV;
- PDF simples;
- despesas recorrentes;
- notificações;
- trilha de auditoria.

## P2

- importação;
- integrações externas;
- comparação avançada de estratégias de liquidação;
- interpretação de linguagem natural por IA;
- outras extensões justificadas.

IA não é requisito do núcleo.
