document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.confirm-form').forEach((form) => {
    form.addEventListener('submit', (event) => {
      const message = form.dataset.confirm || 'Confirmar esta ação?';
      if (!window.confirm(message)) event.preventDefault();
    });
  });
});
