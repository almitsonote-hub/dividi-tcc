from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("core.urls")),
    path("conta/", include("accounts.urls")),
    path("grupos/", include("groups.urls")),
    path("despesas/", include("expenses.urls")),
    path("acertos/", include("settlements.urls")),
]
